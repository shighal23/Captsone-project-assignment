# Kesar & Co. — AI Order-Support Copilot

A small, safe automation that reads customer emails about orders, looks up the order, and
**drafts** a reply for a human agent. It never sends anything on its own.

## 1. Scope (what it does / doesn't)
| Does | Doesn't |
|---|---|
| Handles "where is my order / when will it arrive" for **processing** and **shipped** orders | Refunds, cancellations, delivery complaints, delayed/delivered orders, policy or product questions |
| Verifies the sender's email matches the order before sharing any detail | Send emails automatically |
| Escalates everything else to a human with a one-line reason (+ optional Slack alert) | Promise money, replacements, or discounts |

Narrow on purpose: ~one intent family done reliably beats many done half-well.

## 2. Flow
```
Email -> find order ID -> lookup (orders.csv; stand-in for Shopify/Sheets)
      -> LLM: classify + draft (sees only minimal order facts, email treated as DATA)
      -> Guardrails in CODE -> AUTO_DRAFT (agent one-click review)  |  NEEDS_HUMAN (+ Slack)
      -> every decision appended to logs/audit.jsonl
```
If the LLM is unavailable (no key / API error), a rule-based fallback runs and goes through
the **same** guardrails, so the system degrades instead of breaking.

## 3. Safety design (the part that matters)
Guardrails live in code, not only in the prompt, because prompts can be talked around.
1. **Identity check** — sender email must equal the order email, else no details are shared.
2. **Allow-list** — only `order_status` / `delivery_date` + status `processing|shipped` can auto-draft.
3. **Prompt injection** — email is wrapped as data; regex + model flag ("ignore previous instructions") -> escalate.
4. **No hallucinated facts** — every order ID, tracking ID, date, ₹ amount in the draft must exist in the order record, else escalate.
5. **No promises** — drafts containing refund/replace/compensation/guarantee/discount words are blocked.
6. **Emotion/legal triggers** — angry tone, "consumer court", fraud etc. -> human.
7. **Data minimisation** — LLM never receives customer email, address, or amount.
8. **Audit log** — decision, reasons, engine used, timestamp for each email.

## 4. Run it
```bash
python copilot.py --demo                       # 8 test emails, works offline (no key needed)
export ANTHROPIC_API_KEY=...                   # optional: enables the LLM path
export SLACK_WEBHOOK_URL=...                   # optional: escalation alerts
python copilot.py --from aarav.mehta@example.com --subject "Status" --body "Where is KC-10231?"
```
Python 3.9+, standard library only.

## 5. Test results
`python copilot.py --demo` -> **8/8** as expected in offline (fallback) mode. Cases: happy path x2,
angry+refund, wrong sender, "delivered but not received", prompt injection, cancellation, product/policy question.
LLM path was **not** tested end-to-end here (no API access in my sandbox) — it shares the same guardrails.

## 6. Known limits (honest list)
- Fallback classifier is keyword-based; weak on sarcasm, mixed intents, long threads.
- Sender verification relies on the From header, which can be spoofed — production needs SPF/DKIM checks or a signed order link.
- Only the first order ID in an email is used.
- Hinglish handled lightly; no language detection.
- orders.csv is a stand-in; real stores need API auth, rate limits, and retries.
- Regex guardrails can be bypassed by creative phrasing; they reduce risk, not eliminate it.

## 7. Next steps (if given more time)
Gmail read + create-draft integration; Shopify/Google Sheets lookup; n8n wrapper for no-code ops;
a larger labelled email set with precision/recall per intent; human feedback loop (agent edits -> prompt improvements);
cost/latency tracking.
